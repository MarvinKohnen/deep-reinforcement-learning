# Deep Reinforcement Learing Abgabe
von: Lisa Angold, Justus Pancke, Daniel Heising

In den Skripten wird teilweise das Modul alive_progress genutzt. Falls du es nicht installieren möchtest, kannst du an den Stellen wo alive_it() an einem for-loop genutzt wird es einfach entfernen.
Ansonsten einfach pip install alive_progress ^^