Groupmembers:
- Silas Blume
- Jan Melle
- Michael Vogt

Our submission is divided for each subtask. Therefore, this folder contains 3 PDF files containing the graphs and explainations,
as well as 3 Jupyter Notebooks which includes the Python code to generate the solutions and all graphs used.

For code executions, the following packages are necessary:
2.1
- numpy
- matplotlib.pyplot

2.2
- enum 
- gymnasium 
- pygame
- numpy
- imageio
- PIL

2.3
- numpy
- matplotlib.pyplot
- gymnasium