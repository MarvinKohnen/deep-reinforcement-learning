Exercise 01:

Group Members:

- Julius Ferber 
- Marvin Kohnen
- Moritz Gehring
 