# Abgabe zu Blatt 3 von Sven Ullmann und Valentin Adam 
- in exercise1.ipynb ist die Programmierung zu Aufgabe 1 a-c
- in ecercise2.ipynb ist die Programmierung zu Aufgabe 2 a